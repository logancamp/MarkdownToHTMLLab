interface CodeParser {
    fun parseCode (filename:String): List<Node>
}